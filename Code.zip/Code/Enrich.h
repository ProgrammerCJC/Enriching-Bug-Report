#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <unordered_map>
#include <cmath>
#include <algorithm>
#include <unordered_set>
#include <set>
#include <ctime>
#include <cstdio>
#include <fstream>
#include <ctime>
#include <sstream>
using namespace std;
const int KNN_SIZE = 3;
ofstream outFile[KNN_SIZE];
struct cSentence
{
	vector<string> terms_unigram;
	unordered_map<string, int> terms_unigrams_times; //the time that terms exist in sentence
	vector<pair<string, string> > terms_bigrams;
	map<pair<string, string> , int> terms_bigrams_times; 
	string bugID;
	string SenID;
	int topic;
	int idx;
};
struct cBugReport
{
	string bugID;
	string prod;
	vector<string> summ_unigram;
	vector<string> desc_unigram;

	vector<pair<string, string> > summ_bigram;
	vector<pair<string, string> > desc_bigram;

	unordered_set<string> terms_unigram;
	set<pair<string, string> > terms_bigram;

	string Comp;
	string sever;
	string assignee;
	string commenter;
	int topic[50];
	int total_topic;
	string resolution;
};

struct Result
{
	double BM25_unigram;
	double BM25_bigram;
	double topic;
	double comp;
	double prod;
	double Score;
	int SenID;
};

int top_k[KNN_SIZE] = {3,4,5};

vector<cBugReport> tot_BR; //all of the bugreport
unordered_map<string, int> BgList; //the map of bugID and the idx of totBR��
vector<cSentence> tot_Senten; //all of the sentence
unordered_map<string, int> StList; //the map of Sentence and the idx of tot_Senten��

unordered_map<string, unordered_set<int> > word_in_sentenceID_unigram; //term exist in which sentences 
map<pair<string,string>, unordered_set<int> > word_in_sentenceID_bigram; //term exist in which sentences 

unordered_map<string, vector<int> > senten_bug; //flag each bug_report with sentence'idx

int totalLen_Senten_unigram = 0;
int totalLen_Senten_bigram = 0;

