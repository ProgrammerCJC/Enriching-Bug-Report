__author__ = 'Programmer_C'
from xml.dom import minidom
import nltk,re,pprint,csv,sys
reload(sys)
sys.setdefaultencoding('utf-8')
theme = 'OpenOffice'
filename= theme + '.xml'
fp = open( theme + '.csv', 'wb')
fp_senten = open( theme + '_sentense.csv', 'wb')
fp_ori = open( theme + '_ori.csv', 'wb')
output_file = csv.writer(fp)
output_senten = csv.writer(fp_senten)
output_ori = csv.writer(fp_ori)
stopwords = nltk.corpus.stopwords.words('english')

def get_attrvalue(node, attrname):
    return node.getAttribute(attrname) if node else ''

def get_nodevalue(node):
    return node.childNodes[0].nodeValue if node else ''

def get_xmlnode(node,name):
    return node.getElementsByTagName(name) if node else []

def getContent(aim):
    tokens = nltk.word_tokenize(aim)
    content = [w for w in tokens if w.lower() not in stopwords]
    return content

def stemming(content):
    porter = nltk.PorterStemmer()
    por = [porter.stem(t) for t in content]
    topic = ''
    for word in por:
        islegal = False
        for i in range(len(word)):
            if (word[i] >= 'a' and word[i] <= 'z') or (word[i] >= 'A' and word[i] <= 'Z'):
                islegal = True
            else:
                word = word[:i] + " " + word[(i+1):]

        if(islegal):
            help_str = ",".join(word.split())
            help_str = help_str.split(',')
            for str in help_str:
                if(str.__len__() > 2):
                    topic += (str.lower() + ' ')
    return topic

def get_xml_data():
    doc = minidom.parse(filename)
    root = doc.documentElement
    bug_nodes = get_xmlnode(root,'bug')
    for node in bug_nodes:
        try:
            node_bug_id = get_xmlnode(node,'bug_id')
            node_short_desc = get_xmlnode(node,'short_desc')
            node_startTime = get_xmlnode(node, 'creation_ts')
            node_endTime = get_xmlnode(node, 'delta_ts')
            node_product = get_xmlnode(node,'product')
            node_sev = get_xmlnode(node, 'bug_severity')
            node_component = get_xmlnode(node, 'component')
            node_assignee = get_xmlnode(node, 'assigned_to')
            node_long_desc = get_xmlnode(node, 'long_desc')
            node_thetext = get_xmlnode(node_long_desc[0], 'thetext')
        except :
            continue

        try:
            bug_id =get_nodevalue(node_bug_id[0])
            product = get_nodevalue(node_product[0])
            summary = get_nodevalue(node_short_desc[0])
            component = get_nodevalue(node_component[0])
            severity = get_nodevalue(node_sev[0])
            assignee = get_nodevalue(node_assignee[0])
            start_time = get_nodevalue(node_startTime[0])
            end_time = get_nodevalue(node_endTime[0])
        except :
            continue

        #commenter = set()
        commenter = ""
        long_desc = get_xmlnode(node, 'long_desc')


        description = ""
        if len(node_thetext[0].childNodes):
            description += get_nodevalue(node_thetext[0])

        topic1 = ""
        topic2 = ""
        pos = 1
        sent_tokenizer = nltk.data.load('tokenizers/punkt/english.pickle')
        sents = sent_tokenizer.tokenize(summary)
        # print len(stopwords)
        for sentence in sents:
            st_w = stemming(getContent(sentence))
            if len(st_w) == 0:
                continue
            output_senten.writerows([["&"+bug_id + "_" + str(pos),st_w]])
            output_ori.writerows([["&"+bug_id + "_" + str(pos),sentence]])
            topic1 += " " + st_w
            pos += 1

        start = 0

        for node2 in long_desc:
            node_who = get_xmlnode(node2, 'who')
            dev = get_nodevalue(node_who[0])
            commenter += dev + " "
            # if dev != assignee:
            #     commenter.add(dev)

            content = ''
            node_comment = get_xmlnode(node2, 'thetext')
            if len(node_comment[0].childNodes) == 0:
                continue
            content = get_nodevalue(node_comment[0])
            sent_tokenizer = nltk.data.load('tokenizers/punkt/english.pickle')
            sents = sent_tokenizer.tokenize(content)
            start += 1
            for sentence in sents:
                st_w = stemming(getContent(sentence))
                if len(st_w) == 0:
                    continue
                if(st_w and start == 1):
                    output_ori.writerows([["&"+bug_id + "_" + str(pos),sentence]])
                    output_senten.writerows([["&"+bug_id + "_" + str(pos),st_w]])
                    topic2 += " " + st_w
                    pos += 1
                else:
                    output_ori.writerows([[bug_id + "_" + str(pos),sentence]])
                    output_senten.writerows([[bug_id + "_" + str(pos),st_w]])
                    pos += 1

        commter_out = ""
        for str_com in commenter:
            commter_out += str_com + ' '

        bug = [[ bug_id, product, topic1,topic2,component,severity,
                assignee,commenter,start_time,end_time]]
        output_file.writerows(bug)

def EnrichStopWords():
    file = open("stopwords.txt")
    while 1:
        line = file.readline()
        if not line:
            break
        line=line.strip('\n')
        if line not in stopwords:
            stopwords.append(line)

if __name__ == "__main__":
    EnrichStopWords()
    get_xml_data()