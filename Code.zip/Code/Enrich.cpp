#include "ASE.h"
int string_to_int(string str)
{
	int ans = 0;
	for (int i = 0; i < str.size(); i++)
		ans = ans * 10 + (str[i] - '0');
	return ans;
}

string int_to_string(int num)
{
	stringstream ss;
	ss << num;
	string s1 = ss.str();
	return s1;
}
/*****************read csv*******************/
cBugReport getBR(string str)
{
	//bugid,prod,summary,description,component,sever,proority,assignee,commenter
	cBugReport tempBR;
	tempBR.total_topic = 0;
	memset(tempBR.topic, 0, sizeof(tempBR.topic));
	int idx = str.find(',');
	string bugID = str.substr(0, idx); //get bugid
	str = str.substr(idx + 1, str.size());
	tempBR.bugID = bugID;

	idx = str.find(',');
	tempBR.prod = str.substr(0, idx); //get prod
	str = str.substr(idx + 1, str.size());


	idx = str.find(',');
	string strSumm = str.substr(0, idx); //get summary
	str = str.substr(idx + 1, str.size());
	string fea = "";
	int wTimes = 0;
	pair<string, string> temp_bigram;
	for (int i = 0; i < strSumm.size(); i++)
	{
		if (strSumm[i] == ' ')
		{
			tempBR.summ_unigram.push_back(fea);
			tempBR.terms_unigram.insert(fea);
			wTimes++;
			if (wTimes == 2) //bigram
			{
				temp_bigram = make_pair(tempBR.summ_unigram[0], tempBR.summ_unigram[1]);
				tempBR.summ_bigram.push_back(temp_bigram);
				tempBR.terms_bigram.insert(temp_bigram);
			}
			else if (wTimes > 2)
			{
				temp_bigram.first = temp_bigram.second;
				temp_bigram.second = fea;
				tempBR.summ_bigram.push_back(temp_bigram);
				tempBR.terms_bigram.insert(temp_bigram);
			}
			fea = "";
		}
		else
			fea += strSumm[i];
	}

	idx = str.find(',');
	string strDesc = str.substr(0, idx); //get Desc
	str = str.substr(idx + 1, str.size());
	fea = "";
	wTimes = 0;
	for (int i = 0; i < strDesc.size(); i++)
	{
		if (strDesc[i] == ' ')
		{
			tempBR.desc_unigram.push_back(fea);
			tempBR.terms_unigram.insert(fea);
			wTimes++;
			if (wTimes == 2) //bigram
			{
				temp_bigram = make_pair(tempBR.desc_unigram[0], tempBR.desc_unigram[1]);
				tempBR.desc_bigram.push_back(temp_bigram);
				tempBR.terms_bigram.insert(temp_bigram);
			}
			else if (wTimes > 2)
			{
				temp_bigram.first = temp_bigram.second;
				temp_bigram.second = fea;
				tempBR.desc_bigram.push_back(temp_bigram);
				tempBR.terms_bigram.insert(temp_bigram);
			}
			fea = "";
		}
		else
			fea += strDesc[i];
	}
	if (str[0] == '\"')
		idx = str.rfind('\"')+1;
	else
		idx = str.find(",");
	string comp = str.substr(0, idx); //get comp
	if (comp.find(",") != -1)
		comp = comp.substr(0, comp.find(",")) + comp.substr(comp.find(",") + 1, comp.size());

	tempBR.Comp = comp;
	str = str.substr(idx + 1, str.size());

	idx = str.find(',');
	tempBR.sever = str.substr(0, idx);
	str = str.substr(idx + 1, str.size()); //get sev

	//idx = str.find(',');
	//tempBR.priority = str.substr(0, idx);
	//str = str.substr(idx + 1, str.size()); //get priority

	idx = str.find(',');
	tempBR.assignee = str.substr(0, idx);
	str = str.substr(idx + 1, str.size()); //get assignee
	
	idx = str.find(',');
	tempBR.commenter = str.substr(0, idx);
	tempBR.resolution = str.substr(idx + 1, str.size());

	return tempBR;
}
//read Bug Report
void readBugReport(string theme)
{
	string path = theme + ".csv";
	ifstream in(path);
	string line;
	int idx = 0;
	while (getline(in, line))
	{
		cBugReport report = getBR(line); //�洢bug_repor
		tot_BR.push_back(report);
		BgList[report.bugID] = idx++;
	}
}

cSentence getSentence(string str, int SentenceID)
{
	cSentence tempSen;
	tempSen.topic = -1;
	tempSen.idx = SentenceID;
	int idx = str.find(",");
	string SenID = str.substr(0, idx); //get bugid
	tempSen.SenID = SenID;
	
	if (SenID[0] == '&') //flag
		tempSen.bugID = SenID.substr(1, SenID.find("_"));
	else
		tempSen.bugID = SenID.substr(0, SenID.find("_"));

	senten_bug[tempSen.bugID].push_back(SentenceID);

	string strSumm = str.substr(idx + 1, str.size()); //get terms
	string fea = "";
	int wTimes = 0;
	pair<string, string> temp_bigram;
	for (int i = 0; i < strSumm.size(); i++)
	{
		if (strSumm[i] == ' ')
		{
			tempSen.terms_unigram.push_back(fea);
			tempSen.terms_unigrams_times[fea]++;
			word_in_sentenceID_unigram[fea].insert(SentenceID);

			wTimes++;
			if (wTimes == 2) //bigram
			{
				temp_bigram = make_pair(tempSen.terms_unigram[0], tempSen.terms_unigram[1]);
				tempSen.terms_bigrams.push_back(temp_bigram);
				tempSen.terms_bigrams_times[temp_bigram]++;
				word_in_sentenceID_bigram[temp_bigram].insert(SentenceID);
			}
			else if (wTimes > 2)
			{
				temp_bigram.first = temp_bigram.second;
				temp_bigram.second = fea;
				tempSen.terms_bigrams.push_back(temp_bigram);
				tempSen.terms_bigrams_times[temp_bigram]++;
				word_in_sentenceID_bigram[temp_bigram].insert(SentenceID);
			}
			fea = "";
		}
		else
			fea += strSumm[i];
	}
	return tempSen;
}
//read Sentence
void readSentence(string theme)
{
	ifstream in("csv_" + theme + "_Sentence.csv");
	string line;
	int idx = 0;
	while (getline(in, line) )
	{
		cSentence Senten = getSentence(line, idx); //store bug_report
		tot_Senten.push_back(Senten);
		senten_bug[Senten.bugID].push_back(idx);
		StList[Senten.SenID] = idx;
		totalLen_Senten_unigram += Senten.terms_unigram.size();
		totalLen_Senten_bigram += Senten.terms_bigrams.size();
		idx++;
	}
}
//read topic
void readTopic(string theme)
{
	ifstream in("csv_" + theme + "_Sentence-document-topic-distributuions.csv");
	string line;
	while (getline(in, line))
	{
		int idx = -1;
		idx = line.find(',');
		string SenID = line.substr(0, idx);
		line = line.substr(idx + 1, line.size());
		int cnt = 0;
		vector<double> topic_temp;
		bool legal = false;
		while (idx = line.find(","), idx != -1)
		{
			string sTnum = line.substr(0, idx);
			line = line.substr(idx + 1, line.size());
			if (sTnum == "NaN")
				topic_temp.push_back(0);
			else
			{
				topic_temp.push_back(atof(sTnum.c_str()));
				legal = true;
			}
		}
		if (line == "NaN")
			topic_temp.push_back(0);
		else
			topic_temp.push_back(atof(line.c_str()));
		if (!legal)
		{
			tot_Senten[StList[SenID]].topic = -1;
			continue;
		}
		int temp_topic = max_element(topic_temp.begin(), topic_temp.end()) - topic_temp.begin() + 1;
		tot_Senten[StList[SenID]].topic = temp_topic;
		/*if (SenID[0] == '&')
		{*/
			tot_BR[BgList[SenID.substr(0, SenID.find("_"))]].topic[temp_topic]++; //bug report�У�topicΪtemp_topic�Ĵ���
			tot_BR[BgList[SenID.substr(0, SenID.find("_"))]].total_topic++;
		//}
	}
}  



/*****************output bug reports *********************/
string getTotalSentence(vector<string> str)
{
	string res = "";
	for (int i = 0; i < str.size(); i++)
		res += (str[i] + " ");
	return res;
}

void BR_clear(int idx)
{
	vector<string>(tot_BR[idx].summ_unigram).swap(tot_BR[idx].summ_unigram);
	vector<string>(tot_BR[idx].desc_unigram).swap(tot_BR[idx].desc_unigram);
	vector<pair<string, string> >(tot_BR[idx].summ_bigram).swap(tot_BR[idx].summ_bigram);
	vector<pair<string, string> >(tot_BR[idx].desc_bigram).swap(tot_BR[idx].desc_bigram);
	tot_BR[idx].terms_bigram.clear();
	tot_BR[idx].terms_unigram.clear();
}
inline void output(int i, vector<pair<string, double> > Similarity)
{
	for (int j = 0; j < KNN_SIZE; j++)
	{
		outFile[j] << tot_BR[i].bugID << "," << tot_BR[i].prod << ","; //bugid+prod
		outFile[j] << getTotalSentence(tot_BR[i].summ_unigram) << ","; //summary
		outFile[j] << getTotalSentence(tot_BR[i].desc_unigram) ; //description
		for (int k = 0; k < top_k[j]; k++)
			outFile[j] << getTotalSentence(tot_Senten[StList[Similarity[k].first]].terms_unigram) ; //sentence enhancement
		outFile[j] << "," << tot_BR[i].Comp << "," << tot_BR[i].sever << "," ; //comp+sever+priority
		outFile[j] << tot_BR[i].assignee << ","; //assign
		outFile[j] << tot_BR[i].commenter << "," << tot_BR[i].resolution;
		outFile[j] << endl;
	};
	//BR_clear(i);
}



/*********************BM25************************/
double getTF_unigram(int idx_Senten, string term)
{
	double tf_qi = tot_Senten[idx_Senten].terms_unigrams_times[term];
	int len = tot_Senten[idx_Senten].terms_unigram.size();
	double ave_len = (double)totalLen_Senten_unigram / tot_Senten.size();
	double k1 = 2.0;
	double b = 0.8;
	return (tf_qi*(k1 + 1)) / (tf_qi + k1*(1.0 - b + b * len / ave_len));
}
double getIDF_unigram(string term)
{
	double df_qi = word_in_sentenceID_unigram[term].size() - 1;
	return log(((double)tot_Senten.size() - df_qi + 0.5) / (df_qi + 0.5));
}

double getTF_bigram(int idx_Senten, pair<string,string> term)
{
	double tf_qi = tot_Senten[idx_Senten].terms_bigrams_times[term];
	int len = tot_Senten[idx_Senten].terms_bigrams.size();
	double ave_len = (double)totalLen_Senten_bigram / tot_Senten.size();
	double k1 = 2.0;
	double b = 0.8;
	return (double)(tf_qi*(k1 + 1)) / (tf_qi + k1*(1.0 - b + b*len / ave_len));
}
double getIDF_bigram(pair<string, string> term)
{
	double df_qi = word_in_sentenceID_bigram[term].size() - 1;
	return log(((double)tot_Senten.size() - df_qi + 0.5) / (df_qi + 0.5));
}

bool cmp(pair<string, double> a, pair<string, double> b)
{
	return a.second > b.second;
}


vector<pair<string, double> > getSimilarSentence(cBugReport tempBR)
{
	unordered_map<string, Result> BM25_Score; //SentenID -> Result;
	//count BM25_Unigram similarity
	unordered_set<string>::iterator ite_uni;
	for (ite_uni = tempBR.terms_unigram.begin(); ite_uni != tempBR.terms_unigram.end(); ite_uni++)
	{
		unordered_set<int> word_Sentence = word_in_sentenceID_unigram[*ite_uni]; //find idx of words
		unordered_set<int>::iterator ite;
		for (ite = word_Sentence.begin(); ite != word_Sentence.end(); ite++)
		{
			if (tot_Senten[*ite].bugID == tempBR.bugID) 
				continue;
			double TFD = getTF_unigram(*ite, *ite_uni);
			BM25_Score[tot_Senten[*ite].SenID].BM25_unigram += getIDF_unigram(*ite_uni) * TFD;
		}
	}

	set<pair<string, string> >::iterator ite_big;
	//count BM25_Bigram similarity
	for (ite_big = tempBR.terms_bigram.begin(); ite_big != tempBR.terms_bigram.end(); ite_big++)
	{
		unordered_set<int> word_Sentence = word_in_sentenceID_bigram[*ite_big];
		unordered_set<int>::iterator ite;
		for (ite = word_Sentence.begin(); ite != word_Sentence.end(); ite++)
		{
			if (tot_Senten[*ite].bugID == tempBR.bugID)
				continue;
			BM25_Score[tot_Senten[*ite].SenID].BM25_bigram += getIDF_bigram(*ite_big) * getTF_bigram(*ite, *ite_big);
		}
	}

	for (int i = 0; i < tot_Senten.size(); i++)
	{
		if (tot_Senten[i].bugID == tempBR.bugID)
			continue;
		if (tot_BR[BgList[tot_Senten[i].bugID]].Comp == tempBR.Comp)
			BM25_Score[tot_Senten[i].SenID].comp = 1.0;
		if (tot_BR[BgList[tot_Senten[i].bugID]].prod == tempBR.prod)
			BM25_Score[tot_Senten[i].SenID].prod = 1.0;
		if (tempBR.total_topic != 0 && tot_Senten[i].topic != -1)
			BM25_Score[tot_Senten[i].SenID].topic += (double)tempBR.topic[tot_Senten[i].topic] / tempBR.total_topic;
	}

	double w[5] = {2.163, 1.013, 2.285, 0.032, 0 };
	unordered_map<string, Result>::iterator ite;
	vector<pair<string, double> > res_Sim;
	for (ite = BM25_Score.begin(); ite != BM25_Score.end(); ite++)
	{
		double Score = w[0] * ite->second.BM25_unigram +
			w[1] * ite->second.BM25_bigram +
			w[2] * ite->second.comp +
			w[3] * ite->second.prod +
			w[4] * ite->second.topic;
		res_Sim.push_back(make_pair(ite->first , Score));
	}
	sort(res_Sim.begin(), res_Sim.end(), cmp);
	return res_Sim;
}
/*********************BM25************************/
int main()
{
	string theme = "Eclipse";
	readBugReport(theme);
	readSentence(theme);
	readTopic(theme);
	for (int i = 0; i < KNN_SIZE; i++)
		outFile[i].open(theme + "_Top(topic)" + int_to_string(top_k[i]) + ".csv");
	/*set<string> ID_flag;
	ifstream in("ID_Ori.txt");
	string line;
	while (getline(in, line))
		ID_flag.insert(line);
	ofstream temp_out("Mozilla_out.txt");
	int idx = 0;*/
	for (int i = 0; i < tot_BR.size(); i++)
	{
		if (i % 100 == 0)
			printf("Proceed %d/%d\n", i, tot_BR.size());

		vector<pair<string, double> > Similar = getSimilarSentence(tot_BR[i]);
		output(i, Similar);
	}
	return 0;
}