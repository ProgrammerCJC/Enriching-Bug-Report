#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <unordered_map>
#include <cmath>
#include <algorithm>
#include <set>
#include <unordered_set>
#include <ctime>
#include <cstdio>
#include <fstream>
#include <ctime>
#include <sstream>
using namespace std;
string int_to_string(int num)
{
	stringstream ss;
	ss << num;
	string s1 = ss.str();
	return s1;
}
void readTopic(string theme)
{
	ofstream outFile;
	outFile.open(theme + "_Sentence-document-topic-distributuions.csv");
	ifstream in("csv_" + theme + "_Sentence-document-topic-distributuions.csv");
	string line;
	int idx = 1;
	set<string> budID_count;
	while (getline(in, line) && in.good())
	{
		string output;
		int pos = line.find(",");
		string bugID = line.substr(0, pos);
		if (budID_count.count(bugID) == 0)
		{
			idx = 1;
			budID_count.insert(bugID);
		}
		output = bugID + "_" + int_to_string(idx++);
		output += "," + line.substr(pos + 1, line.size());
		outFile << output << endl;
	}
}
int main()
{
	readTopic("Mozilla");
	return 0;
}